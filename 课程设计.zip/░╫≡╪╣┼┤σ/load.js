function $(param){
	if(arguments[1] == true)
		return document.querySelectorAll(param);
	else
		return document.querySelector(param);
}
function ani(){
	$(".popOut").className = "popOut ani";
}
$(".load img").onclick = function(){
	$(".popOut").style.display = "block";
	ani();
	$(".popOutBg").style.display = "block";
};
$(".popOut > span").onclick = function(){
	$(".popOut").style.display = "none";
	$(".popOutBg").style.display = "none";
};
$(".popOutBg").onclick = function(){
	$(".popOut").style.display = "none";
	$(".popOutBg").style.display = "none";
};

var ramuda = document.getElementById('ramuda');
var text = document.getElementById('text');
var login = document.getElementById('login');
var span = document .getElementById('span');
//可能随机出现的所有字符
var allchar =[0,1,2,3,4,5,6,7,8,9,"a","b","c","d","e",
"f","g","h","i","j","k","l","m","n","o","p","q","r",
"s","t","u","v","w","x","y","z","A","B","C","D","E",
"F","G","H","I","J","K","L","M","N","O","P","Q","R",
"S","T","U","V","W","X","Y","Z"];

function randomChar(){
    var result = "";
    //四位验证码
    for(var i = 0;i <4;i++){
        var index = Math.floor(Math.random() * 62);
        result += allchar[index];
    }
    ramuda.innerHTML = result;
    //点击登录按钮判断验证码是否正确
    login.onclick = function(){
        if(text.value == result){
            alert("登录验证成功");
        }else{
            alert("验证码输入错误");
            randomChar();
            text.value = "";//输入错误清空输入框
        }
    };
}
randomChar();
//换一张也清空输入框
span.onclick = function(){
    text.value = "";
    randomChar();
}
